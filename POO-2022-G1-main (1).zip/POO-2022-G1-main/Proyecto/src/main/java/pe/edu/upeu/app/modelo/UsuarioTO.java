
package pe.edu.upeu.app.modelo;

import lombok.Data;

@Data
public class UsuarioTO {    
    public String  nombre,apellido,usuario,clave;
    public int idUsuario;
}
