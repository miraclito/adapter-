/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pe.edu.upeu.app.gui;

public class Selector extends javax.swing.JFrame {

    public Selector() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnGCliente = new javax.swing.JButton();
        btnGCategoria = new javax.swing.JButton();
        btnGProducto = new javax.swing.JButton();
        btnGMarca = new javax.swing.JButton();
        btnGUsuarios = new javax.swing.JButton();
        btnGVenta = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 255, 204));

        btnGCliente.setText("GESTIONAR CLIENTE");
        btnGCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGClienteActionPerformed(evt);
            }
        });

        btnGCategoria.setText("GESTIONAR CATEGORIA");
        btnGCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGCategoriaActionPerformed(evt);
            }
        });

        btnGProducto.setText("GESTIONAR PRODUCTO");
        btnGProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGProductoActionPerformed(evt);
            }
        });

        btnGMarca.setText("GESTIONAR MARCA");
        btnGMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGMarcaActionPerformed(evt);
            }
        });

        btnGUsuarios.setText("GESTIONAR USUARIO");
        btnGUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGUsuariosActionPerformed(evt);
            }
        });

        btnGVenta.setText("GESTIONAR VENTA");
        btnGVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGVentaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGCliente)
                    .addComponent(btnGUsuarios))
                .addGap(64, 64, 64)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnGMarca)
                    .addComponent(btnGCategoria))
                .addGap(79, 79, 79)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGProducto)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnGVenta)
                        .addGap(12, 12, 12)))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGCliente)
                    .addComponent(btnGProducto)
                    .addComponent(btnGCategoria))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 131, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGUsuarios)
                    .addComponent(btnGMarca)
                    .addComponent(btnGVenta))
                .addGap(106, 106, 106))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGCategoriaActionPerformed
        MainCategoria mc = new MainCategoria();
        mc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnGCategoriaActionPerformed

    private void btnGProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnGProductoActionPerformed

    private void btnGClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGClienteActionPerformed
        MainCliente mc = new MainCliente();
        mc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnGClienteActionPerformed

    private void btnGUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGUsuariosActionPerformed
        MainUsuario mu = new MainUsuario();
        mu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnGUsuariosActionPerformed

    private void btnGMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGMarcaActionPerformed
        MainMarca mu = new MainMarca();
        mu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnGMarcaActionPerformed

    private void btnGVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGVentaActionPerformed
        MainVentas mu = new MainVentas();
        mu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnGVentaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGCategoria;
    private javax.swing.JButton btnGCliente;
    private javax.swing.JButton btnGMarca;
    private javax.swing.JButton btnGProducto;
    private javax.swing.JButton btnGUsuarios;
    private javax.swing.JButton btnGVenta;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
