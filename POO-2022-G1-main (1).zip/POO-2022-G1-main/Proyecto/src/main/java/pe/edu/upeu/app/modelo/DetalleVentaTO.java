package pe.edu.upeu.app.modelo;

import lombok.Data;

@Data
public class DetalleVentaTO {
    public String idDetalle, idVenta, idProducto;
    public double cantidad, precioUnit, descuento, total;
}
