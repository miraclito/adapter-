/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package pe.edu.upeu.app;

import pe.edu.upeu.app.gui.Login;
import pe.edu.upeu.app.gui.MainVentas;
import pe.edu.upeu.app.memento.Ejemplo;

public class Proyecto {

    public static void main(String[] args) {
        //new MainVentas().setVisible(true);
        //new Login().setVisible(true);
       new Ejemplo().Ejemplo();
    }
}
