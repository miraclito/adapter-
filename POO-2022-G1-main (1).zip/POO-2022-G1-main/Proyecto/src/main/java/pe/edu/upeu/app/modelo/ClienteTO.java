
package pe.edu.upeu.app.modelo;

import javax.swing.JPasswordField;
import javax.swing.JTextField;
import lombok.Data;

@Data
public class ClienteTO {
    public String dniruc, nombresrs, tipo, telefono;


}
