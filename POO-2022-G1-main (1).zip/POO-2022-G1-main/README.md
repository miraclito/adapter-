# PROYECTO PROGRAMACION
## PARTICIPANTES
- Arce Mayta Efrain Nayder (MainCliente)
- Turpo Cauna Jose Samuel (Extras)
- Ito Huanca Franck Lenin (MainCliente)
- Quispe Huarilloclla Jhosef Anthony (Login)
- (Usuario root)
- (Contraseña root)
