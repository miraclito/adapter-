package pe.edu.upeu.app;

import pe.edu.upeu.app.gui.Frm_menu;
import pe.edu.upeu.app.gui.Login2;

public class SysVentasGUIG1 {

    public static void main(String args[]) {

        new Login2().setVisible(true);
        //new Frm_menu().setVisible(true);
    }
}
